
/*
console.log("Extension is loaded....");
var LIT = {
    main : function(){
        console.log("Loading main function");  
        LIT.injectStyle("font-awesome-4.7.0/css/font-awesome.min.css") ;   
        LIT.injectStyle("index.css") ; 
        LIT.injectScript("jquery-1.12.4.js");
        LIT.injectScript("jquery-ui.js");
        LIT.injectScript("knockout-3.2.0.js");
        LIT.injectScript("web.js");          

    },
    injectStyle : function(file){
        var style = document.createElement('link');
        style.rel = 'stylesheet';
        style.type = 'text/css';
        style.href = chrome.extension.getURL(file);
        (document.head||document.documentElement).appendChild(style);
    },
    injectScript : function(file){
        var script = document.createElement('script');
        script.src = chrome.extension.getURL(file);
        (document.head || document.documentElement).appendChild(script);
    }

}

LIT.main();
*/


console.log("Extension is loaded....");

var $LITjq;

// DB API
function LITDB () {
    var self = this;
    self.db  = {};
    self.createDB = function(){
        self.db = openDatabase('litdb', '1.0', 'LIT DB', 2 * 1024 * 1024); 
        return self;
    };
    self.createTables = function(){
        self.db.transaction(function (tx) {   
            tx.executeSql('CREATE TABLE IF NOT EXISTS CONFIG ( key unique, value)'); 
            tx.executeSql('CREATE TABLE IF NOT EXISTS PROFILES (link , fname, lname, fullname, img,  title, company, phone, email, type, level, visitcount, position, lastview, speed)'); 
         });
    };
    self.deleteTables = function(){
        self.db.transaction(function (tx) {   
            tx.executeSql('DROP TABLE IF EXISTS CONFIG'); 
            tx.executeSql('DROP TABLE IF EXISTS PROFILES'); 
         });
    },
    self.executeSql = function(query,params){
        params = params ? params : [];
        return new Promise(function(success,fail){
            self.db.transaction(function (tx) { 
                tx.executeSql(query, params, function (tx, results) { 
                   success(results); 
                }, function (tx, err) {
                    // couldn't read database
                    fail(err);
                }); 
             });
        });
    }
}

// Message Listner
chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {      
      console.log(request);
      if(request.type == 'refresh')
      {
        LIT.autoLoadCheck = LIT.getAutoLoadCheck();
        LIT.pullData();
        LIT.doAutoView();        
      }
      if(request.type == 'pipelineToLead'){
        console.log(request);
        LIT.extractContactDetails(request.id);  
      }
      if(request.type =="autoView"){
        LIT.autoLoadCheck = LIT.getAutoLoadCheck();
        LIT.pullData();
        LIT.doAutoView(); 

      }
      if(request.type == "updateVisit")
      {
        LIT.updateVisit(request.id , request.visitcount);  
      }
      if(request.type =="autoViewTest"){
        LIT.autoLoadCheck = LIT.getAutoLoadCheck();
        LIT.pullData();
        LIT.doAutoView2(); 

      }
    });

// Namespace for Our APP
var LIT = {
    db:{},
    getConfig : function(){
        return {
            url : '',
            pipelineLength : 10,
            pipelineToLeadPerDay : 5,
            profileViewTime: 1000*60*3, // 3 minutes
            today:'',
            todayProfileViewCount : 0,
            todayPipelineCount : 0
        };
    },
    getAutoLoadCheck: function(){
        return  {
            pipeline : false,
            lead : false,
            config : false,
            maintenance : false,
            droped : false
        };
    },
    autoLoadCheck: {},
    config: {},
    VM:{},
    injectStyle: function (file) {
        var style = document.createElement('link');
        style.rel = 'stylesheet';
        style.type = 'text/css';
        style.href = chrome.extension.getURL(file);
        (document.head || document.documentElement).appendChild(style);
    },
    injectScript: function (file) {
        var script = document.createElement('script');
        script.src = chrome.extension.getURL(file);
        (document.head || document.documentElement).appendChild(script);
    },
    waitForElement: function(selector) {
        return new Promise(function (res, rej) {
            waitForElementToDisplay(selector, 200);
            function waitForElementToDisplay(selector, time) {
                if (document.querySelector(selector) != null) {
                    res(document.querySelector(selector));
                }
                else {
                    setTimeout(function () {
                        waitForElementToDisplay(selector, time);
                    }, time);
                }
            }
        });
    },
    waitForDataLoad : function(){
        return new Promise(function(res,rej){
            waitForDataToLoad(200);
            function waitForDataToLoad (time){
                if(LIT.autoLoadCheck.config == true && 
                    LIT.autoLoadCheck.profile ==true &&
                    LIT.autoLoadCheck.lead == true &&
                    LIT.autoLoadCheck.droped == true
                    ){
                        res();
                }
                else{
                    setTimeout(function () {
                        waitForDataToLoad(time);
                    }, time);
                }
            }           
        });
    },
    waitForJqueryUI: function () {
        if (typeof jQuery !== 'undefined' && typeof jQuery.fn.jquery !== 'undefined' && typeof jQuery.ui !== 'undefined') {
            $LITjq = jQuery.noConflict(true);
            jQuery = $ = $LITjq.noConflict(true);
            LIT.main();
        }
        else {
            console.log("jQuery UI not loaded...");
            window.setTimeout(LIT.waitForJqueryUI, 500);
        }
    },
    html: `
    <div id='LITWindow' class='LIT-window LIT-Window-Min'> 
        <div id='LITMinWindow' class='LIT-show'>
            <button id="LIT-open" class="LIT-button">Open LinkedIn Tool <i class="fa fa-expand" aria-hidden="true" ></i></button>
            <span class="LIT-button LIT-WindowDragHandle">
                <i class="fa fa-arrows-alt" aria-hidden="true" ></i> 
            </span>
        </div>
        <div id='LITMaxWindow' class='LIT-hide'>
            <div class="LIT-TitleBar">
                <span class="LIT-Float-Left">
                LinkedIn Tool
                </span>
                <span class="LIT-button LIT-WindowDragHandle LIT-Float-Right">
                    <i class="fa fa-arrows-alt" aria-hidden="true" ></i> 
                </span>
                <button id="LIT-close" class="LIT-button LIT-Float-Right">
                    <i class="fa fa-compress" aria-hidden="true" ></i> 
                </button>
            </div>
            <div class="LIT-tab" data-bind="foreach: tabs">
                <button  data-bind="text: $data, 
                css: { active : $data == $root.chosenTabId() },
                click: $root.goToTab">
                </button>
            </div>
            <div class="LIT-tabcontent">
                <div data-bind="if: chosenTabId() === 'Dashboard'">
                    <div>
                        <table class="LIT-table">                             
                            <tr>
                                <td>Action</td>
                                <td>
                                    <span>
                                        <span class="LIT-button LIT-importButton LIT-RedButton"  data-bind="click: resetAll">
                                            <i class="fa fa-trash" aria-hidden="true" ></i> 
                                        </span>
                                    </span>
                                </td>
                            </tr>
                        </table>    
                    </div>
                </div>
                <div data-bind="if: chosenTabId() === 'Pipeline'">
                    <div>
                        <table class="LIT-table">
                            <tr>
                                <td>
                                    <span>URL</span>
                                
                                    <span class="LIT-button LIT-Float-Right LIT-align-openurlbutton">
                                        <i class="fa " 
                                        data-bind="
                                        css: { 
                                            'fa-external-link' : searchURL().length > 0  , 
                                            'fa-arrow-down' : searchURL().length == 0
                                        },
                                        click: copyAndOpenURL"
                                        aria-hidden="true" ></i> 
                                    </span>
                                </td>
                                <td><input type="text" id="pipelineURL" name="pipelineURL" class="LIN-input" data-bind="value: searchURL"></td>
                            </tr>
                            <tr>
                                <td>Status</td>
                                <td> <span data-bind="text: pipelineStatus"></span> </td>
                            </tr>
                            <tr>
                                <td>Collected Count</td>
                                <td><span data-bind="text: profileCount"></span></td>
                            </tr>   
                            <tr>
                                <td>Action</td>
                                <td>
                                    <span data-bind="
                                    css: { 
                                        'LIT-hide' : searchURL().length == 0,
                                        'LIT-show' : searchURL().length > 0
                                    }">
                                        <span class="LIT-button LIT-importButton"  data-bind="click: importProfile">
                                            <i class="fa " data-bind="
                                            css: { 
                                                'fa-refresh' : (isCollectingProfile() === true)  ,
                                                'fa-spin' : (isCollectingProfile() === true ) ,
                                                'fa-arrow-down' : (isCollectingProfile() === false)
                                            }"
                                            aria-hidden="true" ></i> 
                                        </span>
                                    </span>
                                </td>
                            </tr>
                        </table>    
                    </div>
                    <div data-bind="foreach: profiles()">
                        <div class="LIT-card">
                            <img data-bind="attr: { src: $root.getImage($data.img) }" class="LIT-img" alt="Avatar">
                            <div class="LIT-card-container">
                                <b><a class="LIT-medium-font" data-bind="text: ($data.fname +' '+ $data.lname) , attr: { href: $data.link }"></a></b>
                                <br><br>
                                <span class="LIT-small-font" data-bind="text: ($data.title + ' / '+ $data.company)"></span> 
                                <br>
                            </div>
                        </div>        
                    </div>
                </div>

                <div data-bind="if: chosenTabId() === 'Lead'">
                    <div>
                        <table class="LIT-table">
                            <tr>
                                <td>Status</td>
                                <td> <span data-bind="text: leadStatus"></span> </td>
                            </tr>
                            <tr>
                                <td>Collected Count</td>
                                <td><span data-bind="text: leadCount"></span></td>
                            </tr>   
                            <tr>
                                <td>Action</td>
                                <td>
                                    <span data-bind="
                                    css: { 
                                        'LIT-hide' : profileCount() == 0,
                                        'LIT-show' : profileCount() > 0
                                    }">
                                        <span class="LIT-button LIT-importButton"  data-bind="click: importLead">
                                            <i class="fa " data-bind="
                                            css: { 
                                                'fa-refresh' : (isCollectingLead() === true)  ,
                                                'fa-spin' : (isCollectingLead() === true ) ,
                                                'fa-arrow-down' : (isCollectingLead() === false)
                                            }"
                                            aria-hidden="true" ></i> 
                                        </span>
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td>E-Mail</td>
                                <td>
                                    <label class="LIT-switch">
                                        <input type="checkbox" data-bind="checked: showLevelEmail">
                                        <span class="LIT-slider round"></span>
                                    </label>
                                </td>
                            </tr>
                            <tr>
                                <td>Phone</td>
                                <td>
                                    <label class="LIT-switch">
                                        <input type="checkbox" data-bind="checked: showLevelPhone">
                                        <span class="LIT-slider round"></span>
                                    </label>
                                </td>
                            </tr>
                        </table>    
                    </div>
                    <div data-bind="foreach: leads()">
                        <div class="LIT-card " data-bind="
                        css: { 
                            'LIT-hide' :  $root.showLevel() != $data.level,
                            'LIT-show' :  $root.showLevel() == $data.level
                        }">
                            <img data-bind="attr: { src: $root.getImage($data.img) }" class="LIT-img" alt="Avatar">
                            <div class="LIT-card-container">
                                <b><a class="LIT-medium-font" data-bind="text: ($data.fname +' '+ $data.lname) , attr: { href: $data.link }"></a></b>
                                <br><br>
                                <span class="LIT-small-font" data-bind="text: ($data.title + ' / '+ $data.company)"></span> 
                                <br>
                            </div>
                            <div class="LIT-card-button-container">
                                <span class="LIT-button LIT-card-button" data-bind="click: $root.moveToMaintenance">
                                    <i class="fa fa-handshake-o" aria-hidden="true" ></i> 
                                </span>
                                <span class="LIT-button LIT-card-button" data-bind="click: $root.tryAgain">
                                    <i class="fa fa-level-down" aria-hidden="true" ></i> 
                                </span>
                                <span class="LIT-button LIT-card-button" data-bind="click: $root.dropProfile">
                                    <i class="fa fa-trash" aria-hidden="true" ></i> 
                                </span>
                            </div>
                        </div>        
                    </div>
                </div>
                
                <div data-bind="if: chosenTabId() === 'Maintenance'">
                    <div data-bind="foreach: maintenances()">
                        <div class="LIT-card">
                            <img data-bind="attr: { src: $root.getImage($data.img) }" class="LIT-img" alt="Avatar">
                            <div class="LIT-card-container">
                                <b><a class="LIT-medium-font" data-bind="text: ($data.fname +' '+ $data.lname) , attr: { href: $data.link }"></a></b>
                                <br><br>
                                <span class="LIT-small-font" data-bind="text: ($data.title + ' / '+ $data.company)"></span> 
                                <br>
                            </div>
                            <div class="LIT-card-button-container-maintenance">
                                <select class="LIT-dropdown" data-bind="options:  $root.availableSpeeds ,
                                value: $data.chosenSpeed , event:{ change: $root.changeSpeed}"></select>
                            </div>
                        </div>        
                    </div>
                </div>

                <div data-bind="if: chosenTabId() === 'Dropped'">
                    <div data-bind="foreach: droped()">
                        <div class="LIT-card">
                            <img data-bind="attr: { src: $root.getImage($data.img) }" class="LIT-img" alt="Avatar">
                            <div class="LIT-card-container">
                                <b><a class="LIT-medium-font" data-bind="text: ($data.fname +' '+ $data.lname) , attr: { href: $data.link }"></a></b>
                                <br><br>
                                <span class="LIT-small-font" data-bind="text: ($data.title + ' / '+ $data.company)"></span> 
                                <br>
                            </div>
                            <div class="LIT-card-button-container">
                                <span class="LIT-button LIT-card-button" data-bind="click: $root.addBack">
                                    <i class="fa fa-plus" aria-hidden="true" ></i> 
                                </span>
                            </div>
                        </div>        
                    </div>
                </div>

            </div>
        </div>
    </div>
    `,
    minWindow: function () {

    },
    maxWindow: function () {

    },
    eventRegistration: function () {
        $LITjq("#LIT-open").click(function () {

            $("#LITMinWindow").slideToggle("slow", function () {
                $LITjq("#LITWindow").removeClass("LIT-Window-Min").addClass("LIT-Window-Max");
                $("#LITMaxWindow").slideToggle("slow");
            });

        });

        $LITjq("#LIT-close").click(function () {

            $("#LITMaxWindow").slideToggle("slow", function () {
                $LITjq("#LITWindow").removeClass("LIT-Window-Max").addClass("LIT-Window-Min");
                $("#LITMinWindow").slideToggle("slow");
            });
        });
    },
    setDraggable: function () {
        console.log("Jquery Version : " + $.fn.jquery);
        console.log("Jquery UI Version : " + $.ui.version);

        $LITjq('#LITWindow').draggable(
            {
                scroll: false,
                containment: "window",
                handle: '.LIT-WindowDragHandle'
            }
        );

    },
    addHolder: function () {
        /*
        // append to body
        var div = document.createElement('div');
        div.setAttribute("id", "LITHolder");
        div.innerHTML = LIT.html;
        document.body.append(div);
        */
        $LITjq("body").append(LIT.html);
    },
    getHolder: function () {

    },
    knockoutBind: function () {
        /*
        // Here's my data model
        var ViewModel = function(first, last) {
            this.firstName = ko.observable(first);
            this.lastName = ko.observable(last);
        
            this.fullName = ko.computed(function() {
                // Knockout tracks dependencies automatically. It knows that fullName depends on firstName and lastName, because these get called when evaluating fullName.
                return this.firstName() + " " + this.lastName();
            }, this);
        };
        */
        LIT.VM = new LITViewModel();
        ko.applyBindings(LIT.VM); // This makes Knockout get to work
    },
    syncConfig : function(){
        LIT.db.executeSql('SELECT COUNT(*) rowid FROM CONFIG ').then((r)=>{
            var NoOfRows = r.rows.item(0).rowid;
            if(NoOfRows){
                // Get Config
                LIT.db.executeSql('SELECT key , value FROM CONFIG').then((r)=>{
                    //console.log(r);
                    var count = r.rows.length;    
                    for(var k =0; k< count;k++){
                        var v = r.rows.item(k);
                        LIT.config[v.key] = v.value;
                    }
                    //console.log(LIT.config);
                    LIT.VM.setConfig();
                });
            }
            else{
                // set Config
                for (var k in LIT.config){
                    if (LIT.config.hasOwnProperty(k)) {
                          LIT.db.executeSql('INSERT INTO CONFIG ( key , value) VALUES (?,?)',[k,LIT.config[k]]);
                    }
                }
                LIT.VM.setConfig();
            }
        });
    },
    appendToProfileList : function(rows){
        var count=rows.length;
        for(var k=0; k < count ; k++){
            var row =rows[k];
            LIT.db.executeSql('INSERT INTO PROFILES ( link, fname, lname, fullname, img,  title, company, phone, email, type, level, visitcount, position, lastview, speed) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
            [
                row.link,
                row.fname,
                row.lname,
                row.fullName,
                row.img,
                row.title,
                row.company,
                '',
                '',
                'pipeline',
                0,
                0,
                (new Date).getTime(),
                0,
                0
            ]).then(()=>{ 
                count--;
                if(!count){
                    // Inserted all
                    LIT.pullProfiles();
                }
            });
        }
    },
    tryAgain : function(id){
        LIT.db.executeSql("UPDATE PROFILES SET position= ? WHERE rowid=?",[(new Date).getTime(),id]).then(()=>{
            LIT.pullLeads();
        })        
    },
    dropProfile: function(id){
        LIT.db.executeSql("UPDATE PROFILES SET type=? WHERE rowid=?",["droped",id]).then(()=>{
            LIT.pullLeads();
            LIT.pullDroped();
        }) 
    },
    addBack: function(id){
        LIT.db.executeSql("UPDATE PROFILES SET type=? WHERE rowid=?",["lead",id]).then(()=>{
            LIT.pullLeads();
            LIT.pullDroped();
        })
    },
    moveToMaintenance : function(id){
        LIT.db.executeSql("UPDATE PROFILES SET type=? WHERE rowid=?",["maintenance",id]).then(()=>{
            LIT.pullLeads();
            LIT.pullMaintenance();
        })
    },
    changeSpeed : function(id,speed){
        LIT.db.executeSql("UPDATE PROFILES SET speed=? WHERE rowid=?",[speed,id]).then(()=>{
        })
    },
    pullData : function(){
        LIT.syncConfig();
        LIT.pullProfiles();
        LIT.pullLeads();
        LIT.pullDroped();
        LIT.pullMaintenance();
    },
    pullProfiles : function(){
        LIT.db.executeSql("SELECT rowid, * FROM PROFILES WHERE type='pipeline' ORDER BY position ASC").then((r)=>{
            var profiles = [];
            var count = r.rows.length;
            for(var k=0; k< count; k++){
                profiles.push(r.rows.item(k));
            }
            LIT.VM.loadProfiles(profiles);
        });
    },
    pullLeads : function(){
        LIT.db.executeSql("SELECT rowid, * FROM PROFILES WHERE type='lead' ORDER BY position ASC").then((r)=>{
            var leads = [];
            var count = r.rows.length;
            for(var k=0; k< count; k++){
                leads.push(r.rows.item(k));
            }
            LIT.VM.loadLeads(leads);
        });
    },
    pullMaintenance : function(){
        LIT.db.executeSql("SELECT rowid, * FROM PROFILES WHERE type='maintenance' ORDER BY position ASC").then((r)=>{
            var leads = [];
            var count = r.rows.length;
            for(var k=0; k< count; k++){
                leads.push(r.rows.item(k));
            }
            LIT.VM.loadMaintenances(leads);
        });
    },
    pullDroped : function(){
        LIT.db.executeSql("SELECT rowid, * FROM PROFILES WHERE type='droped' ORDER BY position ASC").then((r)=>{
            var droped = [];
            var count = r.rows.length;
            for(var k=0; k< count; k++){
                droped.push(r.rows.item(k));
            }
            LIT.VM.loadDroped(droped);
        });
    },
    importNextLead : function(){
        var profiles = LIT.VM.profiles();
        var profile = {}
        if(profiles.length > 0)
        {
            profile = profiles[0];
        }
        console.log("Profile to Lead :");
        chrome.runtime.sendMessage({type: 'iAmMain'});
        var msg = {id: profile.rowid, link : profile.link, type: 'getLead'};
        console.log(msg);
        chrome.runtime.sendMessage(msg);
    },
    doAutoView : function(){
        LIT.waitForDataLoad().then(()=>{
            if(LIT.config.pipelineToLeadPerDay == LIT.config.todayProfileViewCount ){
                 chrome.runtime.sendMessage({type: 'notify', name: 'reachedLimit'});
                 LIT.doAutoView2();
                 return;
            }
            if(LIT.VM.profiles().length == 0){
                chrome.runtime.sendMessage({type: 'notify', name: 'emptyPipeline'});
                LIT.doAutoView2();
                return;
            }
            if(LIT.config.today == LIT.getDate() &&LIT.config.pipelineToLeadPerDay > LIT.config.todayProfileViewCount)
            {
                LIT.importNextLead(); return;
            }
            if(LIT.config.today != LIT.getDate()){
                LIT.importNextLead(); return;
            }

        })        
    },
    doAutoView2 : function(){
        LIT.waitForDataLoad().then(()=>{
            var profiles = LIT.VM.maintenances();
            for(var i=0;i<profiles.length;i++){
                var profile = profiles[i];
                if(profile.lastview ==0){
                    // visit it
                    var msg = {id: profile.rowid, link : profile.link, type: 'simplyView' , visitcount : profile.visitcount};
                    console.log(msg);
                    chrome.runtime.sendMessage(msg);
                    return;
                }
                if(profile.speed == '1x'){
                    var d = 1000 * 60 * 60 * 24 * 7; 
                    var t = (new Date).getTime();
                    if(t > profile.lastview + d )
                    {
                        // visit it
                        var msg = {id: profile.rowid, link : profile.link, type: 'simplyView' , visitcount : profile.visitcount};
                        console.log(msg);
                        chrome.runtime.sendMessage(msg);
                        return;
                    }
                }
                if(profile.speed == '2x'){
                    var d = 1000 * 60 * 60 * 24 * 3.5; 
                    var t = (new Date).getTime();
                    if(t > profile.lastview + d )
                    {
                        // visit it
                        var msg = {id: profile.rowid, link : profile.link, type: 'simplyView' , visitcount : profile.visitcount};
                        console.log(msg);
                        chrome.runtime.sendMessage(msg);
                        return;
                    }
                }
                if(profile.speed == '3x'){
                    var d = 1000 * 60 * 60 * 24 * 2; 
                    var t = (new Date).getTime();
                    if(t > profile.lastview + d )
                    {
                        // visit it
                        var msg = {id: profile.rowid, link : profile.link, type: 'simplyView' , visitcount : profile.visitcount};
                        console.log(msg);
                        chrome.runtime.sendMessage(msg);
                        return;
                    }
                }
            }
            
        })
    },
    extractContactDetails : function(id){
        console.log("extractContactDetails");
        LIT.waitForElement('#pv-contact-info').then((e)=>{
            var temp = $('.ci-phone').text().match(/\d/g);
            var phone = Array.isArray(temp)? temp.join('') : '' ;
            var email = $('.ci-email').text().replace('Email','').trim();
            LIT.movePipelineToLead(id,phone,email);
        });
        
    },
    movePipelineToLead : function(id,phone,email){
        console.log("movePipelineToLead");
        var level = 0;
        level =  ((phone.length > 2) ? 1 : level);
        level =  ((email.length > 2) ? 2 : level);
        level =  ((email.length > 2  && phone.length > 2) ? 3 : level);

        LIT.db.executeSql("UPDATE PROFILES SET type='lead', phone=?, email=? , visitcount=1 , level=? WHERE rowid=?",[phone,email,level,id]).then((r)=>{
            if(LIT.config.today != LIT.getDate())
            {
                LIT.db.executeSql("UPDATE CONFIG SET value= ? WHERE key=?",[LIT.getDate(),'today']).then(()=>{
                    LIT.db.executeSql("UPDATE CONFIG SET value= ? WHERE key=?",[LIT.config.todayProfileViewCount +1,'todayProfileViewCount']).then(()=>{
                        chrome.runtime.sendMessage({type: 'notify', name: 'contact',email: email, phone : phone});
                        chrome.runtime.sendMessage({type: 'childDone'});
                        
                    })
                }) 
            }
            else{
                LIT.db.executeSql("UPDATE CONFIG SET value= ? WHERE key=?",[LIT.config.todayProfileViewCount +1,'todayProfileViewCount']).then(()=>{
                        
                    chrome.runtime.sendMessage({type: 'notify', name: 'contact',email: email, phone : phone});
                    chrome.runtime.sendMessage({type: 'childDone'});
                        
                })
            }                       
        });        
    },
    updateVisit : function(id,visitcount){
        setTimeout(() => {
            visitcount = visitcount + 1;

            LIT.db.executeSql("UPDATE PROFILES SET visitcount=? , lastview=? WHERE rowid=?",[visitcount,(new Date).getTime(),id]).then((r)=>{
                chrome.runtime.sendMessage({type: 'childDone'});
            })
        
        }, (1000*60*1));
    },
    getDate : function(){
            var today = new Date();
            var dd = String(today.getDate()).padStart(2, '0');
            var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
            var yyyy = today.getFullYear();

            return dd + '-' + mm + '-' + yyyy;
    },
    main: function () {
        console.log("Loading main function");
        LIT.injectStyle("font-awesome-4.7.0/css/font-awesome.min.css");
        LIT.injectStyle("index.css");

        //
        LIT.config = LIT.getConfig();
        LIT.autoLoadCheck= LIT.getAutoLoadCheck();

        LIT.addHolder();
        LIT.knockoutBind();
        LIT.setDraggable();
        LIT.eventRegistration();

        //Creating Database and get connection pool
        LIT.db = new LITDB();
        LIT.db.createDB();
        LIT.db.createTables();
        LIT.pullData();
        chrome.runtime.sendMessage({type: 'childReady'}); 
        chrome.runtime.sendMessage({type: 'isThereAdmin'});       
    }
}

// View Model 
function LITViewModel() {
    // Data
    var self = this;
    self.result = [];
    self.tabs = ['Dashboard', 'Pipeline', 'Lead', 'Maintenance', 'Dropped'];
    self.chosenTabId = ko.observable(self.tabs[0]);
    self.searchURL = ko.observable('');

    self.profiles = ko.observableArray(self.result);
    self.isCollectingProfile = ko.observable(false);
    self.pipelineStatus = ko.observable('Yet To Start');
    self.profileCount = ko.observable(0);

    self.leads = ko.observableArray(self.result);
    self.isCollectingLead = ko.observable(false);
    self.leadStatus = ko.observable('Yet To Start');
    self.leadCount = ko.observable(0);

    self.showLevelPhone = ko.observable(false);
    self.showLevelEmail = ko.observable(false);
    self.showLevel = ko.computed(function() {
        return (self.showLevelPhone() && self.showLevelEmail() ? 3 : (self.showLevelEmail() ? 2 : (self.showLevelPhone() ? 1 : 0))) ;
    });

    self.maintenances = ko.observableArray(self.result);
    self.availableSpeeds = ko.observableArray(['0x','1x','2x','3x']);
    

    self.droped =  ko.observableArray(self.result);

    // Behaviours    
    self.goToTab = function (tab) {
        self.chosenTabId(tab);
        console.log("Go To Tab :" + tab);
    };

    self.copyAndOpenURL = function () {
        if (self.searchURL().length == 0)
        {
            self.searchURL(window.location.href);
            LIT.db.executeSql('UPDATE CONFIG SET value=? WHERE key=?',[window.location.href,'url']).then((r)=>{
                LIT.syncConfig();
            });
        }            
        else
            window.open(self.searchURL());
    };
    self.importProfile = function () {
        console.log("Importing profile");
        self.isCollectingProfile(true);
        self.pipelineStatus("In Progress");
        $("html").animate({ scrollTop: $(document).height() }, 100, function () {
            setTimeout(self.collectProfile, 5000);
        });
    };

    self.getImage = function (img) {
        if (img == 'Not Found') return 'https://www.w3schools.com/howto/img_avatar.png';
        return img;
    };

    self.collectProfile = function () {
        var data = [];
        $('.search-results__list li').each(function () {
            var fullname = $.trim($(this).find('.actor-name').text());
            var fullName = fullname.split(' '),
                firstName = fullName.shift(),
                lastName = fullName.join(" ");

            var temp = $.trim($(this).find('.subline-level-1').text()).split(' at ');
            var title = temp.shift();
            var company = temp.join(" ");

            var link = $.trim($(this).find('.search-result__result-link').attr("href"));
            if (link === undefined) { link = '/#'; }
            //console.log(link);
            var img = $(this).find('img').attr("src");
            if (img === undefined) { img = 'Not Found'; }
            var entry = {
                fullName: fullname,
                fname: firstName,
                lname: lastName,
                title: title,
                company: company,
                link: window.location.origin + link,
                img: img
            }
            data.push(entry);
        });
        console.log(data);
        LIT.appendToProfileList(data);        
    }

    self.setConfig = function(){  
        console.log("Setting Config in VM ");      
        self.searchURL(LIT.config.url);
        self.profileCount(self.profiles().length);
        LIT.autoLoadCheck.config = true;
    }
    self.setPipelineStatus = function(){
        var total  = self.profiles().length + self.leads().length +  self.maintenances().length +  self.droped().length;
        if( total == LIT.config.pipelineLength )
        {
            self.isCollectingProfile(false);
            self.pipelineStatus("Completed");
        }
        if(total < LIT.config.pipelineLength && total > 0 )
        {
            self.isCollectingProfile(true);
            self.pipelineStatus("In-Progress");
        }  
        if( total == 0 )
        {
            self.isCollectingProfile(false);
            self.pipelineStatus("Yet To Start");
        }
    }

    self.loadProfiles =function(data){
        self.profiles(data);
        self.profileCount(self.profiles().length);
        self.setPipelineStatus();
        self.setLeadStatus();
        LIT.autoLoadCheck.profile = true;      
    }

    self.importLead = function () {
        console.log("Importing profile");
        self.isCollectingLead (true);
        self.leadStatus('In-Progress');
        self.leadCount(self.leads().length);
        LIT.importNextLead();
    };

    self.setLeadStatus = function(){
        var total  =  self.leads().length +  self.maintenances().length +  self.droped().length;
        
        if( self.profiles().length == 0 && total > 0)
        {
            self.isCollectingLead(false);
            self.leadStatus("Completed");
        }
        if(self.profiles().length > 0 && total > 0)
        {
            self.isCollectingLead(true);
            self.leadStatus("In-Progress");
        }
        if( self.profiles().length > 0 && total == 0)
        {
            self.isCollectingLead(false);
            self.leadStatus("Yet To Start");
        }
    }   

    self.loadLeads =function(data){
        self.leads(data);
        self.leadCount(self.leads().length);
        self.setPipelineStatus();
        self.setLeadStatus();
        LIT.autoLoadCheck.lead = true;
    }
    self.loadMaintenances = function(data){
        /* Add Observable */
        for(var i=0;i<data.length;i++){
            data[i].chosenSpeed = ko.observable( data[i].speed? data[i].speed:'0x');
        }
        self.maintenances(data);
        LIT.autoLoadCheck.maintenance = true;
    }
    self.loadDroped =function(data){
        self.droped(data);
        LIT.autoLoadCheck.droped = true;
    }
    self.resetAll = function(){
        LIT.db.deleteTables();
        setTimeout(self.recreate,500);
    }
    self.recreate = function(){
        LIT.db.createTables();
        LIT.config =  LIT.getConfig();        
        LIT.pullData();
    }

    self.tryAgain = function(profile){
        //console.log("Try again profile");
        //console.log(profile);
        LIT.tryAgain(profile.rowid);
    }
    self.dropProfile = function(profile){
        //console.log("Droped profile");
        //console.log(profile);
        LIT.dropProfile(profile.rowid);
    }
    self.addBack = function(profile){
        LIT.addBack(profile.rowid);
    }
    self.moveToMaintenance = function(profile){
        LIT.moveToMaintenance(profile.rowid);
    }
    self.changeSpeed = function(profile){
        LIT.changeSpeed(profile.rowid, profile.chosenSpeed());
    }
};

LIT.waitForJqueryUI();