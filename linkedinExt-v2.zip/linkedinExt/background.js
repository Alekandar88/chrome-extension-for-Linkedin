// Registering Messaging 

var mainTab = 0;
var childTab = 0;
var leadID =0;
var visitcount =1;

var LITNotification ={
    reachedLimit: function(){
        console.log("showing Notification");
        chrome.notifications.create('reminder', {
            type: 'basic',
            iconUrl: '128.png',
            title: 'Lead Collected for the Day !',
            message: 'Reached the Daily Limit !'
         }, function(notificationId) {});
    },
    emptyPipeline : function(){
        console.log("showing Notification");
        chrome.notifications.create('reminder', {
            type: 'basic',
            iconUrl: '128.png',
            title: 'Empty Pipeline!',
            message: 'No More Pipeline profile to collect !'
         }, function(notificationId) {});
         console.log("done Notification");

    },
    contact : function(email,phone){
        console.log("showing Notification");
        chrome.notifications.create('reminder', {
            type: 'basic',
            iconUrl: '128.png',
            title: 'New Lead',
            message: 'You Recieved a new lead!'
         }, function(notificationId) {});
         console.log("done Notification");

    }
};

chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        if(request.type == "notify"){
            if(request.name == "reachedLimit")LITNotification.reachedLimit();
            if(request.name == "emptyPipeline")LITNotification.emptyPipeline();
            if(request.name == "contact")LITNotification.contact(request.email,request.phone );
        }
        if(request.type ==  "isThereAdmin"){
            if(mainTab == 0) {
                mainTab = sender.tab.id;
            }           
        }
        if(request.type == "iAmMain" ){
            mainTab = sender.tab.id;
        }
        if (request.type == "getLead")
        {
            console.log(request);
            var url =  request.link;
            leadID = request.id;
            chrome.tabs.create({ url: url+'detail/contact-info/', active: true },function(tab){
                childTab = tab.id;                
            }); 
        }
        if(request.type == "simplyView"){
            console.log(request);
            var url =  request.link;
            leadID = request.id;
            visitcount = request.visitcount;
            chrome.tabs.create({ url: url, active: true },function(tab){
                childTab = tab.id;                
            });
        }

        if(request.type == "childReady" && sender.tab.id == childTab ){
            console.log(request);
            if(sender.tab.url.includes("detail/contact-info/"))
                chrome.tabs.sendMessage(childTab, {type: "pipelineToLead", id : leadID});
            else
                chrome.tabs.sendMessage(childTab, {type: "updateVisit", id : leadID , visitcount : visitcount });

        }
        if(request.type == "childDone" && sender.tab.id == childTab){
            console.log(request);
            // close child tab
            chrome.tabs.remove(childTab, function() { });
            chrome.tabs.sendMessage(mainTab, {type: "refresh"});
        }
    });

chrome.tabs.onRemoved.addListener(function(tabid, removed) {
    if(tabid == mainTab && mainTab !=0)    mainTab = 0;
})

function autoViewTrigger (){
    if(mainTab != 0)
    {
        chrome.tabs.sendMessage(mainTab, {type: "autoView"});
    }
    else{

    }
    setTimeout(autoViewTrigger, 1000*60*60); // every 1 hour
}
autoViewTrigger();
    

function autoViewTriggerTest (){
    if(mainTab != 0)
    {
        chrome.tabs.sendMessage(mainTab, {type: "autoViewTest"});
    }
    else{

    }
    setTimeout(autoViewTrigger, 1000*60*1); // every 1 hour
}
autoViewTriggerTest();
